import React from 'react';
import { MessageCircle, Instagram } from 'lucide-react';
import Logo from './Logo';

const Header: React.FC = () => {
  return (
    <header className="bg-black text-white py-4 px-6 shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center">
        <div className="flex items-center mb-4 sm:mb-0">
          <Logo size={48} />
          <h1 className="text-2xl font-bold ml-3">MTQ1.5city</h1>
        </div>
        
        <div className="flex items-center space-x-6">
          <a 
            href="https://t.me/MTQCITY" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center hover:text-gray-300 transition-colors"
          >
            <MessageCircle className="mr-2" size={20} />
            <span className="hidden sm:inline">Telegram</span>
          </a>
          <a 
            href="https://www.instagram.com/mtq1.5/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center hover:text-gray-300 transition-colors"
          >
            <Instagram className="mr-2" size={20} />
            <span className="hidden sm:inline">Instagram</span>
          </a>
        </div>
      </div>
    </header>
  );
};

export default Header;