import React from 'react';
import Logo from './Logo';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black text-white py-8 mt-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <Logo size={36} />
            <h2 className="text-xl font-bold ml-3">MTQ1.5city</h2>
          </div>
          
          <div className="text-center md:text-right">
            <p className="text-sm text-gray-400 mb-2">
              Bet Responsibly. Must be 21+ to bet.
            </p>
            <p className="text-xs text-gray-500">
              © {new Date().getFullYear()} MTQ1.5city. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;