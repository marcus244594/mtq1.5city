import React from 'react';
import { Clock, TrendingUp } from 'lucide-react';
import { Match } from '../types';

interface MatchCardProps {
  match: Match;
}

const MatchCard: React.FC<MatchCardProps> = ({ match }) => {
  return (
    <div className="bg-white text-black rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="bg-gray-100 px-4 py-2 border-b border-gray-200 flex items-center justify-between">
        <div className="flex items-center">
          <Clock size={16} className="mr-2 text-gray-600" />
          <span className="text-sm font-medium">{match.time}</span>
        </div>
        <span className="bg-black text-white text-xs font-bold px-2 py-1 rounded">
          {match.league}
        </span>
      </div>
      
      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex-1">
            <p className="font-semibold truncate">{match.homeTeam}</p>
          </div>
          <div className="px-2 font-bold">{match.homeScore}</div>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <p className="font-semibold truncate">{match.awayTeam}</p>
          </div>
          <div className="px-2 font-bold">{match.awayScore}</div>
        </div>
        
        <div className="mt-3 pt-3 border-t border-gray-200">
          <div className="flex justify-between items-center mb-2">
            <div className="text-sm font-medium">
              Total Goals: <span className="font-bold">{match.homeScore + match.awayScore}</span>
            </div>
            <div className="bg-black text-white text-xs px-2 py-1 rounded">
              OVER 1.5
            </div>
          </div>
          
          <div className="flex items-center text-sm text-gray-700">
            <TrendingUp size={14} className="mr-1" />
            <span>Probability: </span>
            <span className="font-bold ml-1">{match.probability}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MatchCard;