import React from 'react';

interface LogoProps {
  size?: number;
}

const Logo: React.FC<LogoProps> = ({ size = 24 }) => {
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <img 
        src="https://i.ibb.co/VxKN3Rj/mtq-logo.jpg" 
        alt="MTQ1.5city Logo" 
        className="w-full h-full object-cover rounded-full border-2 border-white"
      />
      <div className="absolute -bottom-1 -right-1 bg-black text-white text-xs font-bold px-1 rounded">
        1.5+
      </div>
    </div>
  );
};

export default Logo;